package com.tezlaa.tezlaa_admin_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
