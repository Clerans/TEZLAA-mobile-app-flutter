import prisma from '../config/database.js';
import payHereProvider, { PayHereNotificationPayload } from './payhere.provider.js';
import notificationService from './notification.service.js';
import { emitOrderStatusUpdated, emitOrderCreated } from '../sockets/index.js';
import { ApiError } from '../utils/apiError.js';
import { PaymentMethod, PaymentStatus, OrderStatus, ReservationStatus } from '@prisma/client';

export class PaymentService {
  /**
   * Prepares signed PayHere checkout parameters for an order
   */
  async preparePayHereCheckout(orderId: string, userId: string) {
    const order = await prisma.order.findFirst({
      where: {
        OR: [{ id: orderId }, { orderNumber: orderId }],
      },
      include: {
        user: true,
        address: true,
        branch: true,
        items: {
          include: { product: true },
        },
        payments: true,
      },
    });

    if (!order) {
      throw new ApiError(404, 'Order not found');
    }

    if (order.userId !== userId) {
      throw new ApiError(403, 'Unauthorized access to order payment');
    }

    // Must be online payment method
    const isOnline = order.payments.some(
      (p) => p.paymentMethod === PaymentMethod.CARD || p.paymentMethod === PaymentMethod.ONLINE_GATEWAY
    );
    if (!isOnline && order.payments.length > 0 && order.payments[0].paymentMethod === PaymentMethod.CASH_ON_DELIVERY) {
      throw new ApiError(400, 'Cannot initiate online payment for a Cash on Delivery order.');
    }

    // Check if already paid or in terminal state
    const alreadyCompleted = order.payments.some((p) => p.status === PaymentStatus.COMPLETED);
    if (alreadyCompleted || order.status === OrderStatus.CONFIRMED || order.status === OrderStatus.PREPARING || order.status === OrderStatus.READY || order.status === OrderStatus.OUT_FOR_DELIVERY || order.status === OrderStatus.DELIVERED || order.status === OrderStatus.READY_FOR_PICKUP || order.status === OrderStatus.PICKED_UP) {
      throw new ApiError(400, 'This order is already confirmed or completed and cannot be paid again.');
    }

    if (order.status === OrderStatus.CANCELLED) {
      throw new ApiError(400, 'This order has been cancelled and cannot accept payment.');
    }

    if (order.status !== OrderStatus.PENDING) {
      throw new ApiError(400, `Cannot initiate payment for order in ${order.status} state.`);
    }

    if (!order.user.email || !order.user.email.trim()) {
      throw new ApiError(400, 'A valid email address on your profile is required for online checkout.');
    }
    if (!order.user.phone || !order.user.phone.trim()) {
      throw new ApiError(400, 'A valid phone number on your profile is required for online checkout.');
    }

    const nameParts = (order.user.fullName || '').trim().split(' ');
    const firstName = nameParts[0] || 'Customer';
    const lastName = nameParts.slice(1).join(' ') || firstName;

    let customerAddress = '';
    let customerCity = 'Colombo';

    if (order.orderType === 'DELIVERY') {
      if (!order.address || !order.address.addressLine1?.trim()) {
        throw new ApiError(400, 'A valid delivery address is required for online checkout of delivery orders.');
      }
      customerAddress = order.address.addressLine1.trim();
      customerCity = order.address.city?.trim() || 'Colombo';
    } else {
      customerAddress = order.branch?.address?.trim() || 'TEZLAA Flagship Café';
    }

    const itemsSummary = order.items
      .map((i) => `${i.quantity}x ${i.product?.name || 'Item'}`)
      .join(', ')
      .slice(0, 100);

    const checkoutParams = payHereProvider.createCheckoutPayload({
      orderNumber: order.orderNumber,
      amount: order.grandTotal,
      currency: 'LKR',
      customer: {
        firstName,
        lastName,
        email: order.user.email,
        phone: order.user.phone,
        address: customerAddress,
        city: customerCity,
        country: 'Sri Lanka',
      },
      itemsSummary,
    });

    return checkoutParams;
  }

  /**
   * Authoritative Server-to-Server PayHere Notification Webhook Handler
   */
  async handlePayHereWebhook(payload: PayHereNotificationPayload) {
    console.log(`[PayHere Webhook] Processing notification for order: ${payload.order_id}, status: ${payload.status_code}`);

    // 1. Verify PayHere MD5 Signature
    const isSignatureValid = payHereProvider.verifyNotificationSignature(payload);
    if (!isSignatureValid) {
      console.error(`[PayHere Webhook] ❌ Invalid MD5 signature for order ${payload.order_id}`);
      throw new ApiError(400, 'Invalid payment signature');
    }

    // 2. Find Order with reservations and payments
    const order = await prisma.order.findUnique({
      where: { orderNumber: payload.order_id },
      include: {
        payments: true,
        user: true,
        loyaltyReservation: true,
        couponReservation: true,
      },
    });

    if (!order) {
      console.error(`[PayHere Webhook] ❌ Order not found for order_id: ${payload.order_id}`);
      throw new ApiError(404, 'Order reference not found');
    }

    const expectedAmount = order.grandTotal.toFixed(2);
    const receivedAmount = parseFloat(payload.payhere_amount).toFixed(2);

    // 3. Amount & Currency Verification
    if (expectedAmount !== receivedAmount) {
      console.error(
        `[PayHere Webhook] ❌ Amount mismatch! Expected: ${expectedAmount}, Received: ${receivedAmount}`
      );
      await prisma.payment.updateMany({
        where: { orderId: order.id },
        data: {
          status: PaymentStatus.FAILED,
          gatewayResponse: JSON.parse(
            JSON.stringify({
              error: 'Amount mismatch',
              expectedAmount,
              receivedAmount,
              payload,
            })
          ),
        },
      });
      throw new ApiError(400, 'Payment amount mismatch');
    }

    if (payload.payhere_currency !== 'LKR') {
      console.error(`[PayHere Webhook] ❌ Currency mismatch! Expected LKR, Received: ${payload.payhere_currency}`);
      throw new ApiError(400, 'Invalid currency');
    }

    // 4. Idempotency & Terminal State Checks:
    const hasCompletedPayment = order.payments.some((p) => p.status === PaymentStatus.COMPLETED);

    // If order already has a COMPLETED payment:
    // A duplicate success (2) is idempotent.
    // Delayed failure (-2), cancellation (-1), or pending (0) must NOT regress a confirmed/completed payment.
    if (hasCompletedPayment) {
      if (payload.status_code === '2' || payload.status_code === '0' || payload.status_code === '-1' || payload.status_code === '-2') {
        console.log(`[PayHere Webhook] ℹ️ Order ${order.orderNumber} already has a completed payment. Ignoring out-of-order/duplicate callback with status ${payload.status_code}.`);
        return {
          success: true,
          status: 'COMPLETED',
          message: 'Payment already completed; out-of-order callback safely ignored',
          duplicate: true,
          idempotent: true,
        };
      }
      // Note: status_code -3 (CHARGEBACK) is permitted through to process bank dispute
    }

    const statusCode = payload.status_code;

    // 5. Status Mapping & Atomic Database State Machine
    if (statusCode === '2') {
      const isOrderAlreadyCancelled = order.status === OrderStatus.CANCELLED;

      // SUCCESS (COMPLETED)
      await prisma.$transaction(async (tx) => {
        // Find existing payment or create
        const paymentRecord = order.payments.find((p) => p.paymentMethod === PaymentMethod.CARD) || order.payments[0];

        const gatewayResponse = JSON.parse(
          JSON.stringify({
            ...payload,
            ...(isOrderAlreadyCancelled && {
              flaggedForReconciliation: true,
              reconciliationReason: 'PAYMENT_CAPTURED_AFTER_ORDER_CANCELLED',
              flaggedAt: new Date(),
            }),
          })
        );

        if (paymentRecord) {
          await tx.payment.update({
            where: { id: paymentRecord.id },
            data: {
              status: PaymentStatus.COMPLETED,
              transactionId: payload.payment_id,
              gatewayProvider: payload.method || 'PayHere',
              gatewayResponse,
            },
          });
        } else {
          await tx.payment.create({
            data: {
              orderId: order.id,
              paymentMethod: PaymentMethod.CARD,
              status: PaymentStatus.COMPLETED,
              amount: order.grandTotal,
              currency: 'LKR',
              transactionId: payload.payment_id,
              gatewayProvider: payload.method || 'PayHere',
              gatewayResponse,
            },
          });
        }

        // If order was already cancelled, preserve cancelled state and flag for reconciliation
        if (isOrderAlreadyCancelled) {
          console.warn(`[PayHere Webhook] ⚠️ Payment captured for ALREADY CANCELLED order ${order.orderNumber}. Preserving CANCELLED state and flagging for refund reconciliation.`);
          return;
        }

        // Advance Order to CONFIRMED ONLY if currently in PENDING state (Never regress terminal orders)
        if (order.status === OrderStatus.PENDING) {
          await tx.order.update({
            where: { id: order.id },
            data: {
              status: OrderStatus.CONFIRMED,
            },
          });

          // Commit Coupon Reservation
          if (order.couponReservation && order.couponReservation.status === ReservationStatus.RESERVED) {
            await tx.couponReservation.update({
              where: { id: order.couponReservation.id },
              data: {
                status: ReservationStatus.CONSUMED,
                consumedAt: new Date(),
              },
            });

            await tx.coupon.update({
              where: { id: order.couponReservation.couponId },
              data: {
                usageCount: { increment: 1 },
              },
            });
          } else if (order.couponCode) {
            await tx.coupon.updateMany({
              where: { code: order.couponCode },
              data: {
                usageCount: { increment: 1 },
              },
            });
          }

          // Commit Loyalty Reservation
          if (order.loyaltyReservation && order.loyaltyReservation.status === ReservationStatus.RESERVED) {
            await tx.loyaltyReservation.update({
              where: { id: order.loyaltyReservation.id },
              data: {
                status: ReservationStatus.CONSUMED,
                consumedAt: new Date(),
              },
            });

            const account = await tx.loyaltyAccount.findUnique({
              where: { userId: order.userId },
            });

            if (account) {
              const pointsToDeduct = order.loyaltyReservation.points;
              await tx.loyaltyAccount.update({
                where: { id: account.id },
                data: {
                  points: { decrement: pointsToDeduct },
                },
              });

              await tx.loyaltyTransaction.create({
                data: {
                  loyaltyAccountId: account.id,
                  orderId: order.id,
                  points: -pointsToDeduct,
                  type: 'REDEEMED',
                  description: `Redeemed for Order #${order.orderNumber}`,
                },
              });
            }
          }
        }
      }, { timeout: 20000, maxWait: 10000 });

      if (order.status === OrderStatus.CANCELLED) {
        return {
          success: true,
          status: 'COMPLETED_CANCELLED_ORDER',
          message: 'Payment captured for cancelled order; flagged for reconciliation',
          flaggedForReconciliation: true,
        };
      }

      console.log(`[PayHere Webhook] ✅ Order ${order.orderNumber} successfully marked as PAID and CONFIRMED.`);

      // Notify Customer
      await notificationService.createOrderStatusNotification(
        order.userId,
        order.orderNumber,
        'CONFIRMED',
        order.id
      );

      // Emit Real-Time Order Event via Socket.IO
      emitOrderCreated(order);
      emitOrderStatusUpdated(order.id, order.userId, {
        orderId: order.id,
        orderNumber: order.orderNumber,
        status: OrderStatus.CONFIRMED,
        paymentStatus: PaymentStatus.COMPLETED,
        updatedAt: new Date(),
      }, order.branchId);

      return { success: true, status: 'COMPLETED', message: 'Payment successfully completed' };
    } else if (statusCode === '0') {
      // PENDING - e.g. bank verification or asynchronous authorization
      await prisma.$transaction(async (tx) => {
        const paymentRecord = order.payments.find((p) => p.paymentMethod === PaymentMethod.CARD) || order.payments[0];
        if (paymentRecord) {
          await tx.payment.update({
            where: { id: paymentRecord.id },
            data: {
              status: PaymentStatus.PENDING,
              transactionId: payload.payment_id || paymentRecord.transactionId,
              gatewayProvider: payload.method || 'PayHere',
              gatewayResponse: JSON.parse(JSON.stringify(payload)),
            },
          });
        }
        // NOTE: Reservations are RETAINED for pending authorization. Do NOT release.
      }, { timeout: 20000, maxWait: 10000 });

      console.log(`[PayHere Webhook] ⏳ Order ${order.orderNumber} payment is PENDING authorization.`);

      emitOrderStatusUpdated(order.id, order.userId, {
        orderId: order.id,
        orderNumber: order.orderNumber,
        status: order.status,
        paymentStatus: PaymentStatus.PENDING,
        updatedAt: new Date(),
      }, order.branchId);

      return { success: true, status: 'PENDING', message: 'Payment authorization is pending' };
    } else if (statusCode === '-1') {
      // CANCELLED by user
      await prisma.$transaction(async (tx) => {
        const paymentRecord = order.payments.find((p) => p.paymentMethod === PaymentMethod.CARD) || order.payments[0];
        if (paymentRecord) {
          await tx.payment.update({
            where: { id: paymentRecord.id },
            data: {
              status: PaymentStatus.CANCELLED,
              transactionId: payload.payment_id || paymentRecord.transactionId,
              gatewayProvider: payload.method || 'PayHere',
              gatewayResponse: JSON.parse(JSON.stringify(payload)),
            },
          });
        }

        // If order is still PENDING, mark CANCELLED & release reservations
        if (order.status === OrderStatus.PENDING) {
          await tx.order.update({
            where: { id: order.id },
            data: { status: OrderStatus.CANCELLED },
          });

          if (order.couponReservation && order.couponReservation.status === ReservationStatus.RESERVED) {
            await tx.couponReservation.update({
              where: { id: order.couponReservation.id },
              data: { status: ReservationStatus.RELEASED, releasedAt: new Date() },
            });
          }

          if (order.loyaltyReservation && order.loyaltyReservation.status === ReservationStatus.RESERVED) {
            await tx.loyaltyReservation.update({
              where: { id: order.loyaltyReservation.id },
              data: { status: ReservationStatus.RELEASED, releasedAt: new Date() },
            });
          }
        }
      }, { timeout: 20000, maxWait: 10000 });

      emitOrderStatusUpdated(order.id, order.userId, {
        orderId: order.id,
        orderNumber: order.orderNumber,
        status: OrderStatus.CANCELLED,
        paymentStatus: PaymentStatus.CANCELLED,
        updatedAt: new Date(),
      }, order.branchId);

      return { success: false, status: 'CANCELLED', message: 'Payment cancelled by user' };
    } else if (statusCode === '-2') {
      // FAILED
      await prisma.$transaction(async (tx) => {
        const paymentRecord = order.payments.find((p) => p.paymentMethod === PaymentMethod.CARD) || order.payments[0];
        if (paymentRecord) {
          await tx.payment.update({
            where: { id: paymentRecord.id },
            data: {
              status: PaymentStatus.FAILED,
              transactionId: payload.payment_id || paymentRecord.transactionId,
              gatewayProvider: payload.method || 'PayHere',
              gatewayResponse: JSON.parse(JSON.stringify(payload)),
            },
          });
        }

        // Release reservations if still reserved
        if (order.couponReservation && order.couponReservation.status === ReservationStatus.RESERVED) {
          await tx.couponReservation.update({
            where: { id: order.couponReservation.id },
            data: { status: ReservationStatus.RELEASED, releasedAt: new Date() },
          });
        }

        if (order.loyaltyReservation && order.loyaltyReservation.status === ReservationStatus.RESERVED) {
          await tx.loyaltyReservation.update({
            where: { id: order.loyaltyReservation.id },
            data: { status: ReservationStatus.RELEASED, releasedAt: new Date() },
          });
        }
      }, { timeout: 20000, maxWait: 10000 });

      console.warn(`[PayHere Webhook] ⚠️ Order ${order.orderNumber} payment marked as FAILED`);

      emitOrderStatusUpdated(order.id, order.userId, {
        orderId: order.id,
        orderNumber: order.orderNumber,
        status: order.status,
        paymentStatus: PaymentStatus.FAILED,
        updatedAt: new Date(),
      }, order.branchId);

      return { success: false, status: 'FAILED', message: `Payment failed with status code ${statusCode}` };
    } else if (statusCode === '-3') {
      // CHARGEBACK - preserve audit information & flag for reconciliation
      await prisma.$transaction(async (tx) => {
        const paymentRecord = order.payments.find((p) => p.paymentMethod === PaymentMethod.CARD) || order.payments[0];
        if (paymentRecord) {
          await tx.payment.update({
            where: { id: paymentRecord.id },
            data: {
              status: PaymentStatus.REFUNDED,
              transactionId: payload.payment_id || paymentRecord.transactionId,
              gatewayProvider: payload.method || 'PayHere',
              gatewayResponse: JSON.parse(JSON.stringify({
                ...payload,
                chargeback: true,
                flaggedForReconciliation: true,
                flaggedAt: new Date(),
              })),
            },
          });
        }

        // Reversal of loyalty points if redeemed
        if (order.loyaltyReservation && order.loyaltyReservation.status === ReservationStatus.CONSUMED) {
          const account = await tx.loyaltyAccount.findUnique({
            where: { userId: order.userId },
          });

          if (account) {
            await tx.loyaltyAccount.update({
              where: { id: account.id },
              data: {
                points: { increment: order.loyaltyReservation.points },
              },
            });

            await tx.loyaltyTransaction.create({
              data: {
                loyaltyAccountId: account.id,
                orderId: order.id,
                points: order.loyaltyReservation.points,
                type: 'BONUS',
                description: `Chargeback reconciliation reversal for Order #${order.orderNumber}`,
              },
            });
          }
        }
      }, { timeout: 20000, maxWait: 10000 });

      console.error(`[PayHere Webhook] 🚨 Order ${order.orderNumber} received CHARGEBACK (-3). Audit preserved and flagged for reconciliation.`);

      emitOrderStatusUpdated(order.id, order.userId, {
        orderId: order.id,
        orderNumber: order.orderNumber,
        status: order.status,
        paymentStatus: PaymentStatus.REFUNDED,
        updatedAt: new Date(),
      }, order.branchId);

      return { success: false, status: 'CHARGEBACK', message: 'Chargeback received and flagged for reconciliation' };
    } else {
      console.warn(`[PayHere Webhook] ❓ Unknown status code received: ${statusCode} for order ${order.orderNumber}`);
      return { success: false, status: 'UNKNOWN', message: `Unknown payment status code ${statusCode}` };
    }
  }

  /**
   * Get current payment status for an order
   */
  async getPaymentStatus(orderId: string, userId: string) {
    const order = await prisma.order.findFirst({
      where: {
        OR: [{ id: orderId }, { orderNumber: orderId }],
      },
      include: {
        payments: true,
      },
    });

    if (!order) {
      throw new ApiError(404, 'Order not found');
    }

    if (order.userId !== userId) {
      throw new ApiError(403, 'Unauthorized access to order');
    }

    const payment = order.payments[0] || null;

    return {
      orderId: order.id,
      orderNumber: order.orderNumber,
      orderStatus: order.status,
      paymentStatus: payment?.status || PaymentStatus.PENDING,
      paymentMethod: payment?.paymentMethod || order.payments[0]?.paymentMethod || 'CARD',
      transactionId: payment?.transactionId || null,
      amount: order.grandTotal,
      currency: payment?.currency || 'LKR',
      updatedAt: payment?.updatedAt || order.updatedAt,
    };
  }
}

export const paymentService = new PaymentService();
export default paymentService;

